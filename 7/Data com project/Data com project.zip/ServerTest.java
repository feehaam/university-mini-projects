import javax. swing.JFrame;
public class ServerTest {
      public static void main (String [] args){
            NewJFrame Feeham = new NewJFrame();
            Feeham.setVisible(true);
            Feeham.startRunning();
      }
}
